*PADS-LIBRARY-PART-TYPES-V9*

RZ7889 SOIC127P600X175-8N I ANA 9 1 0 0 0
TIMESTAMP 2026.10.24.10.54.06
"Manufacturer_Name" RZ
"Manufacturer_Part_Number" RZ7889
"Mouser Part Number" 
"Mouser Price/Stock" 
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" SOP-8 3A Single-CH DC Motor Driver Circuit
"Datasheet Link" http://www.rz-mic.com/uploadfile/fj/2011122615211.pdf
"Geometry.Height" 1.75mm
GATE 1 8 0
RZ7889
1 0 U BI
2 0 U FI
3 0 U GND
4 0 U VCC
8 0 U BO_2
7 0 U BO_1
6 0 U FO_2
5 0 U FO_1

*END*
*REMARK* SamacSys ECAD Model
1552281/2128908/2.50/8/3/Integrated Circuit
